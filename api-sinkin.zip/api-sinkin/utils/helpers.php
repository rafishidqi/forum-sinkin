<?php
// helpers.php

// Fungsi untuk mengatur header CORS (Cross-Origin Resource Sharing)
// Ini penting agar aplikasi Android Anda dapat melakukan request ke API PHP Anda.
function set_cors_headers()
{
    // Mengizinkan semua origin (*) untuk pengembangan.
    // DI LINGKUNGAN PRODUKSI, SANGAT DISARANKAN untuk mengganti '*'
    // dengan domain spesifik aplikasi frontend Anda (misalnya, 'https://app.yourdomain.com').
    header("Access-Control-Allow-Origin: *");

    // Mengizinkan metode HTTP yang akan digunakan oleh API Anda.
    header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");

    // Mengizinkan header yang mungkin dikirim oleh klien (misalnya, Content-Type, Authorization).
    header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

    // Mengatur berapa lama hasil preflight request (OPTIONS) dapat di-cache oleh browser.
    header("Access-Control-Max-Age: 3600"); // Cache preflight request selama 1 jam

    // Jika request adalah preflight request (metode OPTIONS), kirim respons kosong dan keluar.
    // Ini adalah bagian dari mekanisme CORS untuk memeriksa izin sebelum request utama dikirim.
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
        http_response_code(204); // 204 No Content
        exit();
    }
}

// Fungsi untuk mengirim respons dalam format JSON
// Parameter $data adalah array asosiatif atau objek yang akan di-encode ke JSON.
// Parameter $statusCode adalah kode status HTTP (default 200 OK).
function send_json_response($data, $statusCode = 200)
{
    set_cors_headers(); // Pastikan CORS header selalu disetel sebelum mengirim respons
    header('Content-Type: application/json'); // Beri tahu klien bahwa respons adalah JSON
    http_response_code($statusCode); // Set kode status HTTP
    echo json_encode($data); // Encode data ke JSON dan cetak
    exit(); // Hentikan eksekusi skrip setelah mengirim respons
}

// Fungsi untuk mendapatkan data JSON dari body request
// Digunakan untuk request POST, PUT, PATCH yang mengirim data dalam format JSON.
function get_json_input()
{
    // Membaca raw data dari body request
    $input = file_get_contents('php://input');
    // Menguraikan string JSON menjadi array asosiatif PHP (true sebagai argumen kedua)
    return json_decode($input, true);
}

// Fungsi untuk mendapatkan token Bearer dari header Authorization
// Berguna untuk API yang memerlukan autentikasi berbasis token.
function get_bearer_token()
{
    // Mendapatkan semua header HTTP dari request
    $headers = getallheaders();
    // Memeriksa apakah header 'Authorization' ada
    if (isset($headers['Authorization'])) {
        // Mencocokkan pola 'Bearer <token>'
        if (preg_match('/Bearer\s(\S+)/', $headers['Authorization'], $matches)) {
            // Mengembalikan token (bagian setelah 'Bearer ')
            return $matches[1];
        }
    }
    // Mengembalikan null jika token tidak ditemukan
    return null;
}

// Fungsi untuk membangun struktur komentar bersarang
function build_nested_comments(array $comments, $parentId = null)
{
    $branch = [];
    foreach ($comments as $comment) {
        if ($comment['parent_id'] == $parentId) {
            $children = build_nested_comments($comments, $comment['id']);
            if (!empty($children)) {
                $comment['children'] = $children;
            } else {
                $comment['children'] = []; // Pastikan selalu ada array kosong jika tidak ada anak
            }
            $branch[] = $comment;
        }
    }
    return $branch;
}

// DIUBAH: Fungsi untuk menghasilkan slug dari sebuah string
function generate_slug($string)
{
    // Konversi string ke lowercase
    $string = strtolower($string);
    // Ganti karakter non-alphanumeric (kecuali spasi dan hyphen) dengan spasi
    $string = preg_replace('/[^a-z0-9\s-]/', '', $string);
    // Ganti spasi dengan hyphen
    $string = preg_replace('/\s+/', '-', $string);
    // Hapus hyphen berulang
    $string = preg_replace('/-+/', '-', $string);
    // Hapus hyphen di awal dan akhir string
    $string = trim($string, '-');
    return $string;
}