<?php
// soft_delete.php
require_once '../koneksi.php'; // Sesuaikan path jika berbeda
require_once '../utils/helpers.php'; // Sesuaikan path jika berbeda

set_cors_headers();

// Pastikan metode request adalah POST (karena kita mengirim data di body)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405); // Method Not Allowed
}

$comment_id = $_POST['comment_id'] ?? null;
$user_id = $_POST['user_id'] ?? null; // User yang mencoba menghapus

// Validasi input
if (empty($comment_id) || empty($user_id)) {
    send_json_response(['success' => false, 'message' => 'Comment ID dan User ID wajib diisi.'], 400); // Bad Request
}

try {
    // 1. Cek kepemilikan komentar
    $stmt_check_owner = mysqli_prepare($conn, "SELECT user_id FROM comments WHERE id = ?");
    if (!$stmt_check_owner) {
        throw new Exception('Gagal menyiapkan statement cek pemilik: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_check_owner, "i", $comment_id);
    mysqli_stmt_execute($stmt_check_owner);
    $result_owner = mysqli_stmt_get_result($stmt_check_owner);
    $comment_owner = mysqli_fetch_assoc($result_owner);
    mysqli_stmt_close($stmt_check_owner);

    if (!$comment_owner) {
        send_json_response(['success' => false, 'message' => 'Komentar tidak ditemukan.'], 404); // Not Found
    }

    if ($comment_owner['user_id'] != $user_id) {
        send_json_response(['success' => false, 'message' => 'Anda tidak memiliki izin untuk menghapus komentar ini.'], 403); // Forbidden
    }

    // 2. Lakukan "soft delete" (update konten dan tandai sebagai dihapus)
    // Asumsi ada kolom `is_deleted` (BOOLEAN/TINYINT) di tabel `comments`
    $new_content = '[komentar dihapus]';
    // $new_username = '[dihapus]'; // DIHAPUS: Karena kolom 'username' tidak ada di tabel 'comments'

    // DIUBAH: Hapus 'username = ?' dari query UPDATE
    $stmt_soft_delete = mysqli_prepare($conn, "UPDATE comments SET content = ?, is_deleted = 1, updated_at = NOW() WHERE id = ?");
    if (!$stmt_soft_delete) {
        throw new Exception('Gagal menyiapkan statement soft delete: ' . mysqli_error($conn));
    }
    // DIUBAH: Sesuaikan bind_param, hanya 'content' dan 'comment_id'
    mysqli_stmt_bind_param($stmt_soft_delete, "si", $new_content, $comment_id);
    mysqli_stmt_execute($stmt_soft_delete);
    mysqli_stmt_close($stmt_soft_delete);

    // Kirim respons sukses
    send_json_response(['success' => true, 'message' => 'Komentar berhasil dihapus (soft delete).'], 200); // OK

} catch (Exception $e) {
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan saat menghapus komentar: ' . $e->getMessage()], 500); // Internal Server Error
}
