<?php
// create.php (atau add_comment.php)
require_once '../koneksi.php'; // Sesuaikan path jika berbeda
require_once '../utils/helpers.php'; // Sesuaikan path jika berbeda

// PASTIKAN TIDAK ADA SPASI, BARIS KOSONG, ATAU KARAKTER LAIN SEBELUM TAG <?php INI
// ATAU SETELAH TAG PENUTUP  (jika digunakan)

set_cors_headers();

// Pastikan metode request adalah POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405); // Method Not Allowed
}

// Dapatkan input dari $_POST (sesuai dengan cara Android mengirim data form-urlencoded)
$user_id = $_POST['user_id'] ?? null;
$post_id = $_POST['post_id'] ?? null;
$content = $_POST['content'] ?? null;
$parent_id = $_POST['parent_id'] ?? null; // Bisa null jika ini komentar tingkat atas

// Validasi input
if (empty($user_id) || empty($post_id) || empty($content)) {
    send_json_response(['success' => false, 'message' => 'User ID, Post ID, dan konten komentar wajib diisi.'], 400); // Bad Request
}

// Konversi parent_id menjadi null jika string kosong atau "null"
if (empty($parent_id) || $parent_id === "null") {
    $parent_id = null;
} else {
    $parent_id = (int)$parent_id; // Pastikan ini integer jika ada
}

try {
    // Masukkan komentar baru ke database
    // Asumsi tabel 'comments' memiliki kolom: id, user_id, post_id, parent_id (nullable), content, created_at, updated_at
    $stmt_insert = mysqli_prepare($conn, "INSERT INTO comments (user_id, post_id, parent_id, content, created_at, updated_at) VALUES (?, ?, ?, ?, NOW(), NOW())");
    if (!$stmt_insert) {
        throw new Exception('Gagal menyiapkan statement insert komentar: ' . mysqli_error($conn));
    }

    // Bind parameter. "iiis" -> integer, integer, integer (nullable), string
    // Untuk parent_id yang nullable, kita bisa menggunakan 'i' dan mengirim null.
    // MySQLi akan mengubah null menjadi NULL di database.
    mysqli_stmt_bind_param($stmt_insert, "iiss", $user_id, $post_id, $parent_id, $content);

    if (mysqli_stmt_execute($stmt_insert)) {
        $new_comment_id = mysqli_insert_id($conn); // Dapatkan ID komentar yang baru dibuat

        // --- Ambil data komentar yang baru dibuat, termasuk username ---
        $stmt_fetch_comment = mysqli_prepare($conn, "SELECT c.id, c.user_id, u.username, c.post_id, c.parent_id, c.content, c.created_at, c.updated_at FROM comments c JOIN users u ON c.user_id = u.id WHERE c.id = ?");
        if (!$stmt_fetch_comment) {
            throw new Exception('Gagal menyiapkan statement fetch komentar baru: ' . mysqli_error($conn));
        }
        mysqli_stmt_bind_param($stmt_fetch_comment, "i", $new_comment_id);
        mysqli_stmt_execute($stmt_fetch_comment);
        $result_fetch_comment = mysqli_stmt_get_result($stmt_fetch_comment);
        $new_comment_data = mysqli_fetch_assoc($result_fetch_comment);
        mysqli_stmt_close($stmt_fetch_comment);

        if ($new_comment_data) {
            // Pastikan parent_id dikirim sebagai null jika memang null dari DB
            $new_comment_data['parent_id'] = $new_comment_data['parent_id'] ? (int)$new_comment_data['parent_id'] : null;

            // Kirim respons sukses dengan data komentar yang baru dibuat
            send_json_response(['success' => true, 'message' => 'Komentar berhasil ditambahkan!', 'data' => $new_comment_data], 201); // Created
        } else {
            send_json_response(['success' => false, 'message' => 'Komentar berhasil ditambahkan, tetapi gagal mengambil detailnya.'], 500);
        }
    } else {
        send_json_response(['success' => false, 'message' => 'Gagal menambahkan komentar: ' . mysqli_error($conn)], 500); // Internal Server Error
    }
} catch (Exception $e) {
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan saat menambahkan komentar: ' . $e->getMessage()], 500); // Internal Server Error
}