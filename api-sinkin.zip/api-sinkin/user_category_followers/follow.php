<?php
// follow.php
require_once '../koneksi.php'; // Sesuaikan path jika berbeda
require_once '../utils/helpers.php'; // Sesuaikan path jika berbeda

set_cors_headers();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405);
}

$user_id = $_POST['user_id'] ?? null;
$category_id = $_POST['category_id'] ?? null;

// Validasi input
if (empty($user_id) || empty($category_id)) {
    send_json_response(['success' => false, 'message' => 'User ID dan Category ID wajib diisi.'], 400);
}

try {
    // Cek apakah user sudah mengikuti kategori ini
    $stmt_check = mysqli_prepare($conn, "SELECT id FROM user_category_followers WHERE user_id = ? AND category_id = ?");
    if (!$stmt_check) {
        throw new Exception('Gagal menyiapkan statement cek follow: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_check, "ii", $user_id, $category_id);
    mysqli_stmt_execute($stmt_check);
    mysqli_stmt_store_result($stmt_check);

    if (mysqli_stmt_num_rows($stmt_check) > 0) {
        mysqli_stmt_close($stmt_check);
        send_json_response(['success' => false, 'message' => 'Anda sudah mengikuti kategori ini.'], 409); // Conflict
    }
    mysqli_stmt_close($stmt_check);

    // Jika belum mengikuti, tambahkan record baru
    $stmt_insert = mysqli_prepare($conn, "INSERT INTO user_category_followers (user_id, category_id, created_at, updated_at) VALUES (?, ?, NOW(), NOW())");
    if (!$stmt_insert) {
        throw new Exception('Gagal menyiapkan statement insert follow: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_insert, "ii", $user_id, $category_id);
    mysqli_stmt_execute($stmt_insert);
    mysqli_stmt_close($stmt_insert);

    send_json_response(['success' => true, 'message' => 'Kategori berhasil diikuti.'], 201); // Created

} catch (Exception $e) {
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan saat mengikuti kategori: ' . $e->getMessage()], 500);
}