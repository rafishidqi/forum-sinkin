<?php
header('Content-Type: application/json'); // Mengatur header agar respons berupa JSON

// --- Konfigurasi Database dan Helper ---
require_once '../koneksi.php'; // Pastikan path ini benar ke file koneksi Anda
require_once '../utils/helpers.php'; // Pastikan path ini benar ke file helpers Anda

// Fungsi untuk mengirim respons JSON (asumsi sudah ada di helpers.php)
// function send_json_response($data, $status_code = 200) { ... }
// function set_cors_headers() { ... }

set_cors_headers(); // Mengatur header CORS

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405);
}

// Ambil data dari body request POST
$user_id_from_client = $_POST['user_id'] ?? null;
$full_name = $_POST['fullName'] ?? null;
$username = $_POST['username'] ?? null;
$email = $_POST['email'] ?? null;
$bio = $_POST['bio'] ?? null;
$avatar_base64 = $_POST['avatar_base64'] ?? null; // String Base64 dari gambar avatar
$current_avatar_url = $_POST['currentAvatarUrl'] ?? null; // URL avatar saat ini dari client

// --- DEBUGGING LOGS ---
error_log("DEBUG: Request received for user_id: " . $user_id_from_client);
error_log("DEBUG: avatar_base64 length: " . (empty($avatar_base64) ? '0' : strlen($avatar_base64)));
error_log("DEBUG: currentAvatarUrl: " . ($current_avatar_url ?? 'NULL'));
// --- END DEBUGGING LOGS ---


// Validasi input dasar
if (empty($user_id_from_client) || !is_numeric($user_id_from_client)) {
    send_json_response(['success' => false, 'message' => 'User ID tidak valid.'], 400);
}
if (empty($full_name) || empty($username) || empty($email)) {
    send_json_response(['success' => false, 'message' => 'Nama Lengkap, Username, dan Email wajib diisi.'], 400);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    send_json_response(['success' => false, 'message' => 'Format email tidak valid.'], 400);
}

// Inisialisasi variabel untuk URL avatar baru
$new_avatar_url = $current_avatar_url; // Defaultnya adalah URL avatar yang sudah ada

try {
    // --- Proses Unggah Avatar (Jika ada Base64 string baru) ---
    if (!empty($avatar_base64)) {
        error_log("DEBUG: avatar_base64 is NOT empty. Starting image processing.");
        // Hapus "data:image/jpeg;base64," atau "data:image/png;base64," dari string
        $data = explode(',', $avatar_base64);
        $encoded_image = count($data) > 1 ? $data[1] : $data[0];
        $decoded_image = base64_decode($encoded_image);

        if ($decoded_image === false) {
            throw new Exception('Gagal mendekode gambar Base64. Pastikan format Base64 benar.');
        }
        error_log("DEBUG: Base64 decoded successfully. Decoded image size: " . strlen($decoded_image) . " bytes.");

        // Dapatkan ekstensi file dari tipe MIME (opsional, bisa juga dari string Base64)
        $mime_type = 'image/jpeg'; // Default, Anda bisa mencoba mendeteksinya lebih baik
        if (strpos($data[0], 'image/png') !== false) {
            $mime_type = 'image/png';
        } elseif (strpos($data[0], 'image/gif') !== false) {
            $mime_type = 'image/gif';
        }

        $extension = 'jpg'; // Default
        if ($mime_type == 'image/png') {
            $extension = 'png';
        } elseif ($mime_type == 'image/gif') {
            $extension = 'gif';
        }

        // Buat nama file unik
        $file_name = uniqid() . '_' . $user_id_from_client . '.' . $extension;
        $upload_dir = '../../public/uploads/avatars/'; // Sesuaikan path ini
        $file_path = $upload_dir . $file_name;

        error_log("DEBUG: Attempting to save image to: " . $file_path);

        // Pastikan direktori ada dan bisa ditulis
        if (!is_dir($upload_dir)) {
            error_log("DEBUG: Upload directory does not exist. Attempting to create: " . $upload_dir);
            if (!mkdir($upload_dir, 0775, true)) { // Buat direktori jika belum ada
                throw new Exception('Gagal membuat direktori unggahan: ' . $upload_dir);
            }
            error_log("DEBUG: Upload directory created successfully.");
        }
        if (!is_writable($upload_dir)) {
            throw new Exception('Direktori unggahan tidak dapat ditulis: ' . $upload_dir . '. Periksa izin folder.');
        }

        // Simpan gambar ke server
        if (file_put_contents($file_path, $decoded_image) === false) {
            throw new Exception('Gagal menyimpan gambar ke server. Pastikan izin folder benar.');
        }
        error_log("DEBUG: Image saved successfully to: " . $file_path);


        // Hapus avatar lama jika ada dan berbeda dari yang baru
        if (!empty($current_avatar_url)) {
            $old_file_name = basename($current_avatar_url);
            $old_file_path = $upload_dir . $old_file_name;
            error_log("DEBUG: Checking for old avatar: " . $old_file_path);
            if (file_exists($old_file_path) && $old_file_name !== $file_name) {
                if (unlink($old_file_path)) {
                    error_log("DEBUG: Old avatar deleted: " . $old_file_path);
                } else {
                    error_log("WARNING: Failed to delete old avatar: " . $old_file_path);
                }
            }
        }

        // Buat URL publik untuk gambar
        $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
        $new_avatar_url = $base_url . '/public/uploads/avatars/' . $file_name;
        error_log("DEBUG: New avatar URL generated: " . $new_avatar_url);
    } else {
        error_log("DEBUG: avatar_base64 is empty. No new avatar to process.");
    }

    // --- Update Data Pengguna di Database ---
    $stmt = mysqli_prepare($conn, "UPDATE users SET name = ?, username = ?, email = ?, bio = ?, avatar = ?, updated_at = NOW() WHERE id = ?");
    if (!$stmt) {
        throw new Exception('Gagal menyiapkan statement update profil: ' . mysqli_error($conn));
    }

    // Pastikan bio tidak null, jika kosong kirim string kosong
    $bio_to_save = $bio ?? '';
    // Pastikan avatar_url tidak null, jika kosong kirim string kosong
    $avatar_url_to_save = $new_avatar_url ?? '';

    error_log("DEBUG: Binding parameters for DB update. Avatar URL to save: " . $avatar_url_to_save);
    mysqli_stmt_bind_param($stmt, "sssssi", $full_name, $username, $email, $bio_to_save, $avatar_url_to_save, $user_id_from_client);

    if (!mysqli_stmt_execute($stmt)) {
        throw new Exception('Gagal mengeksekusi update profil: ' . mysqli_stmt_error($stmt));
    }
    error_log("DEBUG: Database update executed successfully.");

    mysqli_stmt_close($stmt);

    // --- Ambil Data Pengguna yang Diperbarui untuk Respons ---
    $stmt_fetch = mysqli_prepare($conn, "SELECT id, name, username, email, bio, avatar FROM users WHERE id = ?");
    if (!$stmt_fetch) {
        throw new Exception('Gagal menyiapkan statement fetch user: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_fetch, "i", $user_id_from_client);
    mysqli_stmt_execute($stmt_fetch);
    $result_fetch = mysqli_stmt_get_result($stmt_fetch);
    $updated_user_data = mysqli_fetch_assoc($result_fetch);
    mysqli_stmt_close($stmt_fetch);

    if ($updated_user_data) {
        // Format ulang data agar sesuai dengan model User di Android
        $response_data = [
            'uid' => (string)$updated_user_data['id'], // Sesuaikan jika UID di Android adalah string
            'fullName' => $updated_user_data['name'],
            'username' => $updated_user_data['username'],
            'email' => $updated_user_data['email'],
            'bio' => $updated_user_data['bio'],
            'avatarUrl' => $updated_user_data['avatar'] // URL avatar yang baru
        ];
        error_log("DEBUG: Profile updated successfully. Responding with data.");
        send_json_response(['success' => true, 'message' => 'Profil berhasil diperbarui.', 'data' => $response_data], 200);
    } else {
        error_log("ERROR: Failed to fetch updated user data after successful update.");
        send_json_response(['success' => false, 'message' => 'Gagal mengambil data profil yang diperbarui.'], 500);
    }
} catch (Exception $e) {
    // Tangani kesalahan umum
    error_log("ERROR in update_profile.php: " . $e->getMessage()); // Log error ke server
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()], 500);
} finally {
    if (isset($conn) && $conn->ping()) {
        mysqli_close($conn);
    }
}