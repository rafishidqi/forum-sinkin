<?php
// show.php
require_once '../koneksi.php'; // Sesuaikan path jika berbeda
require_once '../utils/helpers.php'; // Sesuaikan path jika berbeda

set_cors_headers();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405);
}

$post_id = $_GET['post_id'] ?? null;
$user_id = $_GET['user_id'] ?? null; // User yang sedang melihat (untuk status vote/save)

if (empty($post_id)) {
    send_json_response(['success' => false, 'message' => 'Post ID tidak ditemukan.'], 400);
}

try {
    // Ambil detail postingan dengan subquery untuk vote_count dan comment_count
    $sql_post = "
        SELECT 
            p.id, p.user_id, u.username, 
            p.category_id, c.name as category_name, 
            p.title, p.slug, p.content, p.image, p.type, p.is_published, p.is_banned,
            p.created_at, p.updated_at,
            COALESCE(vc.upvote_count, 0) AS upvote_count,
            COALESCE(vc.downvote_count, 0) AS downvote_count,
            COALESCE(cc.comment_count, 0) AS comment_count,
            CASE WHEN sp.id IS NOT NULL THEN TRUE ELSE FALSE END AS is_saved_by_user,
            (SELECT type FROM votes WHERE post_id = p.id AND user_id = ? LIMIT 1) AS user_vote_type
        FROM posts p
        JOIN users u ON p.user_id = u.id
        JOIN categories c ON p.category_id = c.id
        LEFT JOIN (
            SELECT post_id,
                   SUM(CASE WHEN type = 'up' THEN 1 ELSE 0 END) AS upvote_count,
                   SUM(CASE WHEN type = 'down' THEN 1 ELSE 0 END) AS downvote_count
            FROM votes
            GROUP BY post_id
        ) AS vc ON p.id = vc.post_id
        LEFT JOIN (
            SELECT post_id, COUNT(id) AS comment_count
            FROM comments
            GROUP BY post_id
        ) AS cc ON p.id = cc.post_id
        LEFT JOIN saved_posts sp ON p.id = sp.post_id AND sp.user_id = ?
        WHERE p.id = ? AND p.is_published = 1 AND p.is_banned = 0
        GROUP BY p.id, u.username, c.name, p.title, p.slug, p.content, p.image, p.type, p.is_published, p.is_banned, p.created_at, p.updated_at, sp.id, vc.upvote_count, vc.downvote_count, cc.comment_count
    ";
    $stmt_post = mysqli_prepare($conn, $sql_post);
    if (!$stmt_post) {
        throw new Exception('Gagal menyiapkan statement post: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_post, "iii", $user_id, $user_id, $post_id);
    mysqli_stmt_execute($stmt_post);
    $result_post = mysqli_stmt_get_result($stmt_post);
    $post = mysqli_fetch_assoc($result_post);
    mysqli_stmt_close($stmt_post);

    if (!$post) {
        send_json_response(['success' => false, 'message' => 'Postingan tidak ditemukan atau tidak aktif.'], 404);
    }

    // Konversi boolean
    $post['is_saved_by_user'] = (bool)$post['is_saved_by_user'];

    // Ambil komentar untuk postingan ini
    $sql_comments = "
        SELECT 
            c.id, c.user_id, u.username, c.post_id, c.parent_id, 
            c.content, c.is_deleted, c.created_at, c.updated_at
        FROM comments c
        JOIN users u ON c.user_id = u.id
        WHERE c.post_id = ?
        ORDER BY c.created_at ASC
    ";
    $stmt_comments = mysqli_prepare($conn, $sql_comments);
    if (!$stmt_comments) {
        throw new Exception('Gagal menyiapkan statement komentar: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_comments, "i", $post_id);
    mysqli_stmt_execute($stmt_comments);
    $result_comments = mysqli_stmt_get_result($stmt_comments);

    $all_comments = [];
    while ($row = mysqli_fetch_assoc($result_comments)) {
        $row['is_deleted'] = (bool)$row['is_deleted']; // Pastikan ini boolean
        $all_comments[] = $row;
    }
    mysqli_stmt_close($stmt_comments);

    // DIUBAH: Gunakan fungsi build_nested_comments dari helpers.php
    $post['comments'] = build_nested_comments($all_comments);

    send_json_response(['success' => true, 'data' => $post], 200);
} catch (Exception $e) {
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()], 500);
}