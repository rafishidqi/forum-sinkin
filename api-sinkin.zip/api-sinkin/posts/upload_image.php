<?php

header('Content-Type: application/json'); // Mengatur header agar respons berupa JSON

// --- Konfigurasi Database dan Helper ---
// Sesuaikan path ini jika file koneksi.php dan helpers.php berada di lokasi yang berbeda
require_once '../koneksi.php';
require_once '../utils/helpers.php'; // Asumsi file ini berisi send_json_response dan set_cors_headers

set_cors_headers(); // Mengatur header CORS untuk mengizinkan permintaan lintas domain

// Memeriksa apakah metode permintaan adalah POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan. Gunakan POST.'], 405);
}

// Ambil data dari body request POST
$imageBase64 = $_POST['image_base64'] ?? null;
$userId = $_POST['user_id'] ?? null; // user_id dari client, untuk penamaan file

// --- DEBUGGING LOGS ---
error_log("DEBUG: Request received for image upload. User ID: " . ($userId ?? 'NULL'));
error_log("DEBUG: image_base64 length: " . (empty($imageBase64) ? '0' : strlen($imageBase64)));
// --- END DEBUGGING LOGS ---

// Validasi input dasar
if (empty($imageBase64)) {
    send_json_response(['success' => false, 'message' => 'Data gambar Base64 tidak ditemukan.'], 400);
}
if (empty($userId) || !is_numeric($userId)) {
    send_json_response(['success' => false, 'message' => 'User ID tidak valid atau tidak ditemukan.'], 400);
}

try {
    // Menghapus prefix data:image/png;base64, jika ada
    $data = explode(',', $imageBase64);
    $encodedImage = count($data) > 1 ? $data[1] : $data[0];
    $encodedImage = str_replace(' ', '+', $encodedImage); // Mengganti spasi dengan + jika ada

    // Mendekode string Base64 menjadi data biner gambar
    $decodedImage = base64_decode($encodedImage);

    if ($decodedImage === false) {
        throw new Exception('Gagal mendekode gambar Base64. Pastikan format Base64 benar.');
    }
    error_log("DEBUG: Base64 decoded successfully. Decoded image size: " . strlen($decodedImage) . " bytes.");

    // Mendapatkan ekstensi file dari tipe MIME data biner
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->buffer($decodedImage);

    $extension = '';
    switch ($mimeType) {
        case 'image/jpeg':
            $extension = 'jpg';
            break;
        case 'image/png':
            $extension = 'png';
            break;
        case 'image/gif':
            $extension = 'gif';
            break;
        default:
            throw new Exception('Tipe file gambar tidak didukung: ' . $mimeType);
    }
    error_log("DEBUG: Detected MIME type: $mimeType, Extension: $extension");

    // Direktori tempat gambar postingan akan disimpan.
    // Sesuaikan path ini agar sesuai dengan struktur folder Anda.
    // Contoh: jika file ini di 'api/posts/', dan 'public/uploads/posts/' adalah target,
    // maka path relatifnya adalah '../../public/uploads/posts/'.
    $upload_dir = '../../public/uploads/posts/';

    // Buat nama file unik
    $fileName = uniqid() . '_' . $userId . '.' . $extension;
    $filePath = $upload_dir . $fileName;

    error_log("DEBUG: Attempting to save image to: " . $filePath);

    // Pastikan direktori ada dan bisa ditulis
    if (!is_dir($upload_dir)) {
        error_log("DEBUG: Upload directory does not exist. Attempting to create: " . $upload_dir);
        if (!mkdir($upload_dir, 0775, true)) { // Buat direktori jika belum ada, dengan izin 0775
            throw new Exception('Gagal membuat direktori unggahan: ' . $upload_dir);
        }
        error_log("DEBUG: Upload directory created successfully.");
    }
    if (!is_writable($upload_dir)) {
        throw new Exception('Direktori unggahan tidak dapat ditulis: ' . $upload_dir . '. Periksa izin folder.');
    }

    // Menyimpan gambar ke server
    if (file_put_contents($filePath, $decodedImage) === false) {
        throw new Exception('Gagal menyimpan gambar ke server. Pastikan izin folder benar.');
    }
    error_log("DEBUG: Image saved successfully to: " . $filePath);

    // Buat URL publik untuk gambar
    // Ini akan membangun URL absolut berdasarkan host saat ini
    $base_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
    $imageUrl = $base_url . '/public/uploads/posts/' . $fileName;
    error_log("DEBUG: Image URL generated: " . $imageUrl);

    send_json_response(['success' => true, 'message' => 'Gambar berhasil diunggah.', 'data' => ['image_url' => $imageUrl]], 200);
} catch (Exception $e) {
    // Tangani kesalahan umum
    error_log("ERROR in upload_image.php: " . $e->getMessage()); // Log error ke server
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()], 500);
} finally {
    // Pastikan koneksi database ditutup jika ada
    if (isset($conn) && $conn->ping()) {
        mysqli_close($conn);
    }
}