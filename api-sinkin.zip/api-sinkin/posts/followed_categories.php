<?php
// followed_categories.php
require_once '../koneksi.php';
require_once '../utils/helpers.php';

set_cors_headers();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405);
}

$user_id = $_GET['user_id'] ?? null;

// Validasi input
if (empty($user_id)) {
    send_json_response(['success' => false, 'message' => 'User ID wajib diisi.'], 400);
}

try {
    // Ambil daftar category_id yang diikuti oleh pengguna
    $followed_categories = [];
    $stmt_followed_categories = mysqli_prepare($conn, "SELECT category_id FROM user_category_followers WHERE user_id = ?");
    if ($stmt_followed_categories) {
        mysqli_stmt_bind_param($stmt_followed_categories, "i", $user_id);
        mysqli_stmt_execute($stmt_followed_categories);
        $result_followed_categories = mysqli_stmt_get_result($stmt_followed_categories);
        while ($row = mysqli_fetch_assoc($result_followed_categories)) {
            $followed_categories[] = $row['category_id'];
        }
        mysqli_stmt_close($stmt_followed_categories);
    }

    $posts = [];
    if (!empty($followed_categories)) {
        $category_placeholders = implode(',', array_fill(0, count($followed_categories), '?'));

        // DIUBAH: Menggunakan subquery untuk upvote_count, downvote_count, comment_count, dan is_saved_by_user
        // Ini mencegah duplikasi hitungan yang disebabkan oleh JOIN langsung ke tabel votes dan comments
        $sql_posts = "
            SELECT 
                p.id, p.user_id, u.username, 
                p.category_id, c.name as category_name, 
                p.title, p.slug, p.content, p.image, p.type, p.is_published, p.is_banned,
                p.created_at, p.updated_at,
                (SELECT COALESCE(SUM(CASE WHEN type = 'up' THEN 1 ELSE 0 END), 0) FROM votes WHERE post_id = p.id) AS upvote_count,
                (SELECT COALESCE(SUM(CASE WHEN type = 'down' THEN 1 ELSE 0 END), 0) FROM votes WHERE post_id = p.id) AS downvote_count,
                (SELECT COUNT(id) FROM comments WHERE post_id = p.id) AS comment_count,
                (SELECT CASE WHEN id IS NOT NULL THEN TRUE ELSE FALSE END FROM saved_posts WHERE post_id = p.id AND user_id = ? LIMIT 1) AS is_saved_by_user,
                (SELECT type FROM votes WHERE post_id = p.id AND user_id = ? LIMIT 1) AS user_vote_type
            FROM posts p
            JOIN users u ON p.user_id = u.id
            JOIN categories c ON p.category_id = c.id
            WHERE p.category_id IN ($category_placeholders)
            AND p.is_published = 1 AND p.is_banned = 0
            ORDER BY p.created_at DESC
        ";

        $stmt_posts = mysqli_prepare($conn, $sql_posts);
        if (!$stmt_posts) {
            throw new Exception('Gagal menyiapkan statement fetch posts: ' . mysqli_error($conn));
        }

        // Buat array parameter untuk bind_param
        // Pertama, user_id untuk is_saved_by_user dan user_vote_type
        // Kemudian, category_id's
        $params = array_merge([$user_id, $user_id], $followed_categories);
        $types = str_repeat('i', count($params)); // Semua parameter adalah integer

        mysqli_stmt_bind_param($stmt_posts, $types, ...$params);
        mysqli_stmt_execute($stmt_posts);
        $result_posts = mysqli_stmt_get_result($stmt_posts);

        while ($row = mysqli_fetch_assoc($result_posts)) {
            // Konversi is_saved_by_user ke boolean
            $row['is_saved_by_user'] = (bool)$row['is_saved_by_user'];
            $posts[] = $row;
        }
        mysqli_stmt_close($stmt_posts);
    }

    send_json_response(['success' => true, 'message' => 'Ikuti kategori untuk melihat postingan!', 'data' => $posts], 200);
} catch (Exception $e) {
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()], 500);
}