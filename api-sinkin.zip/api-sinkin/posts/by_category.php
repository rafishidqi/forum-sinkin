<?php
// by_category.php
require_once '../koneksi.php'; // Sesuaikan path jika berbeda
require_once '../utils/helpers.php'; // Sesuaikan path jika berbeda

set_cors_headers();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405);
}

$category_id = $_GET['category_id'] ?? null;
$user_id = $_GET['user_id'] ?? null; // User yang sedang melihat (untuk status vote/save)

// Validasi input
if (empty($category_id)) {
    send_json_response(['success' => false, 'message' => 'Category ID wajib diisi.'], 400);
}

try {
    // Ambil postingan berdasarkan category_id, dengan hitungan vote, komentar, dan status save/vote pengguna
    $sql_posts = "
        SELECT 
            p.id, p.user_id, u.username, 
            p.category_id, c.name as category_name, 
            p.title, p.slug, p.content, p.image, p.type, p.is_published, p.is_banned,
            p.created_at, p.updated_at,
            COALESCE(vc.upvote_count, 0) AS upvote_count,
            COALESCE(vc.downvote_count, 0) AS downvote_count,
            COALESCE(cc.comment_count, 0) AS comment_count,
            CASE WHEN sp.id IS NOT NULL THEN TRUE ELSE FALSE END AS is_saved_by_user,
            (SELECT type FROM votes WHERE post_id = p.id AND user_id = ? LIMIT 1) AS user_vote_type
        FROM posts p
        JOIN users u ON p.user_id = u.id
        JOIN categories c ON p.category_id = c.id
        LEFT JOIN (
            SELECT post_id,
                   SUM(CASE WHEN type = 'up' THEN 1 ELSE 0 END) AS upvote_count,
                   SUM(CASE WHEN type = 'down' THEN 1 ELSE 0 END) AS downvote_count
            FROM votes
            GROUP BY post_id
        ) AS vc ON p.id = vc.post_id
        LEFT JOIN (
            SELECT post_id, COUNT(id) AS comment_count
            FROM comments
            GROUP BY post_id
        ) AS cc ON p.id = cc.post_id
        LEFT JOIN saved_posts sp ON p.id = sp.post_id AND sp.user_id = ?
        WHERE p.category_id = ? AND p.is_published = 1 AND p.is_banned = 0
        ORDER BY p.created_at DESC
    ";

    $stmt_posts = mysqli_prepare($conn, $sql_posts);
    if (!$stmt_posts) {
        throw new Exception('Gagal menyiapkan statement postingan berdasarkan kategori: ' . mysqli_error($conn));
    }
    // Bind user_id dua kali untuk subquery is_saved_by_user dan user_vote_type, lalu category_id
    mysqli_stmt_bind_param($stmt_posts, "iii", $user_id, $user_id, $category_id);
    mysqli_stmt_execute($stmt_posts);
    $result_posts = mysqli_stmt_get_result($stmt_posts);

    $posts = [];
    while ($row = mysqli_fetch_assoc($result_posts)) {
        $row['is_saved_by_user'] = (bool)$row['is_saved_by_user'];
        $posts[] = $row;
    }
    mysqli_stmt_close($stmt_posts);

    send_json_response(['success' => true, 'message' => 'Postingan berhasil dimuat.', 'data' => $posts], 200);
} catch (Exception $e) {
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()], 500);
}
