<?php
// vote.php
require_once '../koneksi.php';
require_once '../utils/helpers.php'; // Pastikan helpers.php dimuat untuk build_nested_comments

set_cors_headers();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405);
}

$user_id = $_POST['user_id'] ?? null;
$post_id = $_POST['post_id'] ?? null;
$type = $_POST['type'] ?? null; // "up" atau "down"

// Validasi input
if (empty($user_id) || empty($post_id) || !in_array($type, ['up', 'down'])) {
    send_json_response(['success' => false, 'message' => 'Input tidak valid. Tipe vote harus "up" atau "down".'], 400);
}

try {
    // Cek apakah user sudah pernah vote postingan ini
    $stmt_check = mysqli_prepare($conn, "SELECT id, type FROM votes WHERE user_id = ? AND post_id = ?");
    if (!$stmt_check) {
        throw new Exception('Gagal menyiapkan statement cek vote: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_check, "ii", $user_id, $post_id);
    mysqli_stmt_execute($stmt_check);
    $result_check = mysqli_stmt_get_result($stmt_check);
    $existing_vote = mysqli_fetch_assoc($result_check);
    mysqli_stmt_close($stmt_check);

    if ($existing_vote) {
        // Jika user sudah vote
        if ($existing_vote['type'] === $type) {
            // Jika vote-nya sama, berarti user ingin membatalkan vote
            $stmt_delete = mysqli_prepare($conn, "DELETE FROM votes WHERE id = ?");
            if (!$stmt_delete) {
                throw new Exception('Gagal menyiapkan statement delete vote: ' . mysqli_error($conn));
            }
            mysqli_stmt_bind_param($stmt_delete, "i", $existing_vote['id']);
            mysqli_stmt_execute($stmt_delete);
            mysqli_stmt_close($stmt_delete);
            $message = 'Vote dibatalkan.';
        } else {
            // Jika vote-nya berbeda, berarti user ingin mengubah vote
            $stmt_update = mysqli_prepare($conn, "UPDATE votes SET type = ?, updated_at = NOW() WHERE id = ?");
            if (!$stmt_update) {
                throw new Exception('Gagal menyiapkan statement update vote: ' . mysqli_error($conn));
            }
            mysqli_stmt_bind_param($stmt_update, "si", $type, $existing_vote['id']);
            mysqli_stmt_execute($stmt_update);
            mysqli_stmt_close($stmt_update);
            $message = 'Vote diubah menjadi ' . $type . '.';
        }
    } else {
        // Jika user belum pernah vote, tambahkan vote baru
        $stmt_insert = mysqli_prepare($conn, "INSERT INTO votes (user_id, post_id, type, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())");
        if (!$stmt_insert) {
            throw new Exception('Gagal menyiapkan statement insert vote: ' . mysqli_error($conn));
        }
        mysqli_stmt_bind_param($stmt_insert, "iis", $user_id, $post_id, $type);
        mysqli_stmt_execute($stmt_insert);
        mysqli_stmt_close($stmt_insert);
        $message = 'Vote ' . $type . ' berhasil.';
    }

    // --- Ambil data postingan yang diperbarui setelah aksi vote ---
    // Menggunakan subquery untuk semua hitungan dan status agar tidak terpengaruh join
    $sql_fetch_updated_post = "
        SELECT 
            p.id, p.user_id, u.username, 
            p.category_id, c.name as category_name, 
            p.title, p.slug, p.content, p.image, p.type, p.is_published, p.is_banned,
            p.created_at, p.updated_at,
            (SELECT COALESCE(SUM(CASE WHEN type = 'up' THEN 1 ELSE 0 END), 0) FROM votes WHERE post_id = p.id) AS upvote_count,
            (SELECT COALESCE(SUM(CASE WHEN type = 'down' THEN 1 ELSE 0 END), 0) FROM votes WHERE post_id = p.id) AS downvote_count,
            (SELECT COUNT(id) FROM comments WHERE post_id = p.id) AS comment_count, -- Subquery untuk menghitung komentar
            (SELECT CASE WHEN id IS NOT NULL THEN TRUE ELSE FALSE END FROM saved_posts WHERE post_id = p.id AND user_id = ? LIMIT 1) AS is_saved_by_user, -- Subquery untuk status disimpan
            (SELECT type FROM votes WHERE post_id = p.id AND user_id = ? LIMIT 1) AS user_vote_type -- Subquery untuk vote user saat ini
        FROM posts p
        JOIN users u ON p.user_id = u.id
        JOIN categories c ON p.category_id = c.id
        WHERE p.id = ? -- Hanya ambil postingan yang relevan
        GROUP BY p.id, u.username, c.name, p.title, p.slug, p.content, p.image, p.type, p.is_published, p.is_banned, p.created_at, p.updated_at
    ";

    $stmt_fetch_post = mysqli_prepare($conn, $sql_fetch_updated_post);
    if (!$stmt_fetch_post) {
        throw new Exception('Gagal menyiapkan statement fetch updated post: ' . mysqli_error($conn));
    }
    // Bind user_id dua kali untuk subquery is_saved_by_user dan user_vote_type, lalu post_id
    mysqli_stmt_bind_param($stmt_fetch_post, "iii", $user_id, $user_id, $post_id);
    mysqli_stmt_execute($stmt_fetch_post);
    $result_fetch_post = mysqli_stmt_get_result($stmt_fetch_post);
    $updated_post = mysqli_fetch_assoc($result_fetch_post);
    mysqli_stmt_close($stmt_fetch_post);

    if ($updated_post) {
        // Konversi is_saved_by_user ke boolean
        $updated_post['is_saved_by_user'] = (bool)$updated_post['is_saved_by_user'];

        // Ambil data komentar untuk postingan ini
        $sql_fetch_comments = "
            SELECT 
                comm.id, comm.user_id, u_comm.username, comm.post_id, comm.parent_id, comm.content, comm.is_deleted, comm.created_at, comm.updated_at
            FROM comments comm
            JOIN users u_comm ON comm.user_id = u_comm.id
            WHERE comm.post_id = ?
            ORDER BY comm.created_at ASC
        ";
        $stmt_fetch_comments = mysqli_prepare($conn, $sql_fetch_comments);
        if (!$stmt_fetch_comments) {
            error_log('Gagal menyiapkan statement fetch comments: ' . mysqli_error($conn));
            // Lanjutkan tanpa komentar jika gagal, tapi log errornya
            $updated_post['comments'] = [];
        } else {
            mysqli_stmt_bind_param($stmt_fetch_comments, "i", $post_id);
            mysqli_stmt_execute($stmt_fetch_comments);
            $result_comments = mysqli_stmt_get_result($stmt_fetch_comments);
            $all_comments = []; // Gunakan nama variabel yang konsisten
            while ($row = mysqli_fetch_assoc($result_comments)) {
                $row['is_deleted'] = (bool)$row['is_deleted']; // Pastikan ini boolean
                $all_comments[] = $row;
            }
            mysqli_stmt_close($stmt_fetch_comments);

            // DIUBAH: Gunakan fungsi build_nested_comments dari helpers.php
            $updated_post['comments'] = build_nested_comments($all_comments);
        }

        send_json_response(['success' => true, 'message' => $message, 'data' => $updated_post], 200);
    } else {
        send_json_response(['success' => false, 'message' => 'Postingan tidak ditemukan setelah aksi vote.'], 404);
    }
} catch (Exception $e) {
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan saat vote: ' . $e->getMessage()], 500);
}