<?php
// create_post.php
// SANGAT PENTING: PASTIKAN TIDAK ADA SPASI, BARIS KOSONG, ATAU KARAKTER LAIN SEBELUM TAG <?php INI
// ATAU SETELAH TAG PENUTUP  (jika digunakan, disarankan untuk TIDAK menggunakan tag penutup di file PHP murni)

require_once '../koneksi.php'; // Sesuaikan path jika berbeda (misal: ../koneksi.php jika di posts/)
require_once '../utils/helpers.php'; // Sesuaikan path jika berbeda

// UNTUK DEBUGGING: Anda bisa mengaktifkan error reporting SEMENTARA.
// DI LINGKUNGAN PRODUKSI, PASTIKAN INI DINONAKTIFKAN agar pesan error tidak merusak respons JSON.
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

set_cors_headers();

// Pastikan metode request adalah POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405); // Method Not Allowed
}

// Dapatkan input dari $_POST (karena di Android menggunakan @FormUrlEncoded untuk createPost)
$user_id = $_POST['user_id'] ?? null;
$category_id = $_POST['category_id'] ?? null;
$title = $_POST['title'] ?? '';
$content = $_POST['content'] ?? '';
$image_url = $_POST['image'] ?? null; // Bisa null jika tidak ada gambar

// Validasi input
if (empty($user_id) || empty($category_id) || empty($title) || empty($content)) {
    send_json_response(['success' => false, 'message' => 'User ID, Category ID, Judul, dan Konten wajib diisi.'], 400); // Bad Request
}

// Konversi ke integer untuk memastikan tipe data yang benar
$user_id = (int)$user_id;
$category_id = (int)$category_id;
$title = trim($title);
$content = trim($content);

if (empty($title)) {
    send_json_response(['success' => false, 'message' => 'Judul tidak boleh kosong setelah trim.'], 400);
}
if (empty($content)) {
    send_json_response(['success' => false, 'message' => 'Konten tidak boleh kosong setelah trim.'], 400);
}

try {
    // Cek apakah user_id valid dan ada
    $stmt_user_check = mysqli_prepare($conn, "SELECT id FROM users WHERE id = ?");
    if (!$stmt_user_check) {
        throw new Exception('Gagal menyiapkan statement cek user: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_user_check, "i", $user_id);
    mysqli_stmt_execute($stmt_user_check);
    mysqli_stmt_store_result($stmt_user_check);
    if (mysqli_stmt_num_rows($stmt_user_check) == 0) {
        mysqli_stmt_close($stmt_user_check);
        send_json_response(['success' => false, 'message' => 'User ID tidak ditemukan.'], 404);
    }
    mysqli_stmt_close($stmt_user_check);

    // Cek apakah category_id valid dan ada
    $stmt_category_check = mysqli_prepare($conn, "SELECT id FROM categories WHERE id = ?");
    if (!$stmt_category_check) {
        throw new Exception('Gagal menyiapkan statement cek kategori: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_category_check, "i", $category_id);
    mysqli_stmt_execute($stmt_category_check);
    mysqli_stmt_store_result($stmt_category_check);
    if (mysqli_stmt_num_rows($stmt_category_check) == 0) {
        mysqli_stmt_close($stmt_category_check);
        send_json_response(['success' => false, 'message' => 'Category ID tidak ditemukan.'], 404);
    }
    mysqli_stmt_close($stmt_category_check);

    // Generate slug dari judul
    $slug = generate_slug($title); // Asumsi fungsi generate_slug ada di helpers.php

    // Masukkan postingan baru ke database
    // DIUBAH: Tambahkan `is_banned` ke daftar kolom INSERT dan set nilainya ke 0
    $sql_insert_post = "INSERT INTO posts (user_id, category_id, title, slug, content, image, type, is_published, is_banned, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, 'text', 1, 0, NOW(), NOW())";
    $stmt_insert = mysqli_prepare($conn, $sql_insert_post);
    if (!$stmt_insert) {
        throw new Exception('Gagal menyiapkan statement insert postingan: ' . mysqli_error($conn));
    }

    // DIUBAH: Perbaiki type string untuk bind_param. 's' untuk content, bukan 'i'.
    // Urutan: user_id(i), category_id(i), title(s), slug(s), content(s), image_url(s)
    mysqli_stmt_bind_param(
        $stmt_insert,
        "iissss",
        $user_id,
        $category_id,
        $title,
        $slug,
        $content,
        $image_url
    );

    if (mysqli_stmt_execute($stmt_insert)) {
        $new_post_id = mysqli_insert_id($conn); // Dapatkan ID postingan yang baru dibuat

        // Ambil data postingan yang baru dibuat beserta username dan category_name
        $sql_fetch_new_post = "
            SELECT 
                p.id, p.user_id, u.username, 
                p.category_id, c.name as category_name, 
                p.title, p.slug, p.content, p.image, p.type, p.is_published, p.is_banned,
                p.created_at, p.updated_at,
                0 AS upvote_count, -- Default 0 untuk post baru
                0 AS downvote_count, -- Default 0 untuk post baru
                0 AS comment_count, -- Default 0 untuk post baru
                FALSE AS is_saved_by_user,
                NULL AS user_vote_type
            FROM posts p
            JOIN users u ON p.user_id = u.id
            JOIN categories c ON p.category_id = c.id
            WHERE p.id = ?
            LIMIT 1
        ";
        $stmt_fetch_new_post = mysqli_prepare($conn, $sql_fetch_new_post);
        if (!$stmt_fetch_new_post) {
            error_log('Gagal menyiapkan statement fetch postingan baru: ' . mysqli_error($conn));
            mysqli_stmt_close($stmt_insert);
            throw new Exception('Gagal menyiapkan statement fetch postingan.');
        }
        mysqli_stmt_bind_param($stmt_fetch_new_post, "i", $new_post_id);
        mysqli_stmt_execute($stmt_fetch_new_post);
        $result_new_post = mysqli_stmt_get_result($stmt_fetch_new_post);
        $new_post_data = mysqli_fetch_assoc($result_new_post);
        mysqli_stmt_close($stmt_fetch_new_post);

        mysqli_stmt_close($stmt_insert);

        if ($new_post_data) {
            $new_post_data['is_saved_by_user'] = (bool)$new_post_data['is_saved_by_user'];
            $new_post_data['comments'] = []; // Postingan baru belum punya komentar
            send_json_response([
                'success' => true,
                'message' => 'Postingan berhasil dibuat!',
                'data' => $new_post_data // Mengembalikan objek postingan yang baru dibuat
            ], 201); // Created
        } else {
            send_json_response(['success' => false, 'message' => 'Postingan dibuat, tetapi gagal mengambil detailnya.'], 500);
        }
    } else {
        send_json_response(['success' => false, 'message' => 'Gagal membuat postingan.'], 500);
    }
} catch (Exception $e) {
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan saat membuat postingan: ' . $e->getMessage()], 500); // Internal Server Error
}
// SANGAT PENTING: PASTIKAN TIDAK ADA KODE ATAU SPASI DI SINI SETELAH send_json_response() TERAKHIR
// HINDARI PENGGUNAAN TAG PENUTUP PHP (
?>) JIKA TIDAK ADA HTML DI BAWAHNYA
// Ini untuk mencegah spasi atau baris kosong yang tidak disengaja setelah tag penutup