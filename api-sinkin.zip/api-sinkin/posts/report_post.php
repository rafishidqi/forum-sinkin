<?php
// report_post.php
require_once '../koneksi.php'; // Sesuaikan path jika berbeda
require_once '../utils/helpers.php'; // Sesuaikan path jika berbeda

// PASTIKAN TIDAK ADA SPASI, BARIS KOSONG, ATAU KARAKTER LAIN SEBELUM TAG <?php INI
// ATAU SETELAH TAG PENUTUP (jika digunakan)

set_cors_headers();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405); // Method Not Allowed
}

$user_id = $_POST['user_id'] ?? null;
$post_id = $_POST['post_id'] ?? null;
$reason = $_POST['reason'] ?? null;

// Validasi input
// post_id harus ada, dan reason tidak boleh kosong
if (empty($user_id) || empty($post_id) || empty($reason)) {
    send_json_response(['success' => false, 'message' => 'User ID, Post ID, dan alasan wajib diisi.'], 400); // Bad Request
}

try {
    // Cek apakah laporan serupa sudah ada untuk post ini dari user ini
    $stmt_check = mysqli_prepare($conn, "SELECT id FROM reports WHERE user_id = ? AND post_id = ? AND status = 'pending'");
    if (!$stmt_check) {
        throw new Exception('Gagal menyiapkan statement cek laporan: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_check, "ii", $user_id, $post_id);
    mysqli_stmt_execute($stmt_check);
    $result_check = mysqli_stmt_get_result($stmt_check);
    $existing_report = mysqli_fetch_assoc($result_check);
    mysqli_stmt_close($stmt_check);

    if ($existing_report) {
        send_json_response(['success' => false, 'message' => 'Anda sudah melaporkan postingan ini dan sedang dalam proses.'], 409); // Conflict
    }

    // Masukkan laporan baru ke database
    // Asumsi tabel 'reports' memiliki kolom: id, user_id, post_id, comment_id (nullable), reason, status, created_at, updated_at
    // Status default 'pending'
    $stmt_insert = mysqli_prepare($conn, "INSERT INTO reports (user_id, post_id, reason, status, created_at, updated_at) VALUES (?, ?, ?, 'pending', NOW(), NOW())");
    if (!$stmt_insert) {
        throw new Exception('Gagal menyiapkan statement insert laporan: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_insert, "iis", $user_id, $post_id, $reason);
    mysqli_stmt_execute($stmt_insert);
    mysqli_stmt_close($stmt_insert);

    send_json_response(['success' => true, 'message' => 'Laporan berhasil dikirim. Terima kasih atas kontribusi Anda.'], 201); // Created

} catch (Exception $e) {
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan saat mengirim laporan: ' . $e->getMessage()], 500); // Internal Server Error
}
// PASTIKAN TIDAK ADA KODE ATAU SPASI DI SINI SETELAH send_json_response() TERAKHIR
// HINDARI PENGGUNAAN TAG PENUTUP PHP (
?>) JIKA TIDAK ADA HTML DI BAWAHNYA
// Ini untuk mencegah spasi atau baris kosong yang tidak disengaja setelah tag penutup