<?php
// posts/search.php
require_once '../koneksi.php'; // Sesuaikan path jika berbeda
require_once '../utils/helpers.php'; // Sesuaikan path jika berbeda

// PASTIKAN TIDAK ADA SPASI, BARIS KOSONG, ATAU KARAKTER LAIN SEBELUM TAG <?php INI
// ATAU SETELAH TAG PENUTUP  (jika digunakan)

set_cors_headers();

// Pastikan metode request adalah GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan. Gunakan GET.'], 405); // Method Not Allowed
}

// Dapatkan parameter dari $_GET
$user_id = $_GET['user_id'] ?? null;
$search_query = $_GET['query'] ?? null;

// Validasi input
if (empty($user_id) || empty($search_query)) {
    send_json_response(['success' => false, 'message' => 'User ID dan query pencarian wajib diisi.'], 400); // Bad Request
}

// Pastikan user_id adalah integer
$user_id = (int)$user_id;

try {
    // Query untuk mencari postingan berdasarkan judul atau konten
    // Menggunakan JOIN untuk mendapatkan username dan category_name
    // Menggunakan LEFT JOIN untuk votes dan saved_posts agar tetap menampilkan postingan
    // meskipun user belum memberikan vote atau menyimpan postingan tersebut.
    $sql = "SELECT
                p.id,
                p.user_id,
                u.username,
                p.category_id,
                c.name AS category_name,
                p.title,
                p.slug,
                p.content,
                p.image,
                p.type,
                p.is_published,
                p.is_banned,
                p.created_at,
                p.updated_at,
                COUNT(DISTINCT pv_up.id) AS upvote_count,
                COUNT(DISTINCT pv_down.id) AS downvote_count,
                (SELECT COUNT(*) FROM comments WHERE post_id = p.id) AS comment_count,
                CASE WHEN sp.user_id IS NOT NULL THEN TRUE ELSE FALSE END AS is_saved_by_user,
                CASE
                    WHEN pv_user.type = 'up' THEN 'up'
                    WHEN pv_user.type = 'down' THEN 'down'
                    ELSE NULL
                END AS user_vote_type
            FROM
                posts p
            JOIN
                users u ON p.user_id = u.id
            JOIN
                categories c ON p.category_id = c.id
            LEFT JOIN
                votes pv_up ON p.id = pv_up.post_id AND pv_up.type = 'up'
            LEFT JOIN
                votes pv_down ON p.id = pv_down.post_id AND pv_down.type = 'down'
            LEFT JOIN
                saved_posts sp ON p.id = sp.post_id AND sp.user_id = ?
            LEFT JOIN
                votes pv_user ON p.id = pv_user.post_id AND pv_user.user_id = ?
            WHERE
                (p.title LIKE ? OR p.content LIKE ?) AND p.is_published = 1 AND p.is_banned = 0
            GROUP BY
                p.id
            ORDER BY
                p.created_at DESC";

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        throw new Exception('Gagal menyiapkan statement pencarian: ' . mysqli_error($conn));
    }

    $search_param = "%" . $search_query . "%";
    // Bind parameter. "iiss" -> integer (user_id), integer (user_id), string (search_param), string (search_param)
    mysqli_stmt_bind_param($stmt, "iiss", $user_id, $user_id, $search_param, $search_param);

    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $posts = [];
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            // Konversi nilai sesuai dengan klarifikasi terbaru:
            // is_saved_by_user diharapkan boolean oleh Android (berdasarkan error terakhir)
            $row['is_saved_by_user'] = (bool)$row['is_saved_by_user'];
            // is_published diharapkan integer (0/1) oleh Android (berdasarkan konfirmasi Anda)
            $row['is_published'] = (int)$row['is_published'];
            // is_banned diharapkan integer (0/1) oleh Android (berdasarkan konfirmasi Anda)
            $row['is_banned'] = (int)$row['is_banned'];

            // Pastikan 'image' adalah null jika string kosong
            if (empty($row['image'])) {
                $row['image'] = null;
            }

            $posts[] = $row;
        }
    }

    send_json_response([
        "success" => true,
        "message" => "Hasil pencarian berhasil diambil.",
        "data" => $posts
    ], 200); // OK

    mysqli_stmt_close($stmt);
} catch (Exception $e) {
    send_json_response([
        "success" => false,
        "message" => "Terjadi kesalahan server: " . $e->getMessage(),
        "data" => null
    ], 500); // Internal Server Error
} finally {
    // Pastikan koneksi ditutup jika ada
    if (isset($conn) && $conn instanceof mysqli) {
        mysqli_close($conn);
    }
}