<?php
// update.php
require_once '../koneksi.php'; // Sesuaikan path jika berbeda
require_once '../utils/helpers.php'; // Sesuaikan path jika berbeda

set_cors_headers();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { // Menggunakan POST karena Android @FormUrlEncoded
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405);
}

// Dapatkan input dari $_POST
$post_id = $_POST['post_id'] ?? null;
$user_id = $_POST['user_id'] ?? null;
$category_id = $_POST['category_id'] ?? null;
$title = $_POST['title'] ?? '';
$content = $_POST['content'] ?? '';
$image_url = $_POST['image'] ?? null; // DIUBAH: Ambil URL gambar dari input

// Validasi input
if (empty($post_id) || empty($user_id) || empty($category_id) || empty($title) || empty($content)) {
    send_json_response(['success' => false, 'message' => 'Post ID, User ID, Category ID, Judul, dan Konten wajib diisi.'], 400);
}

// Konversi ke integer
$post_id = (int)$post_id;
$user_id = (int)$user_id;
$category_id = (int)$category_id;
$title = trim($title);
$content = trim($content);

if (empty($title) || empty($content)) {
    send_json_response(['success' => false, 'message' => 'Judul dan konten tidak boleh kosong setelah trim.'], 400);
}

// Generate slug baru dari judul (jika judul berubah)
$slug = generate_slug($title);

try {
    // 1. Cek apakah postingan ada dan dimiliki oleh user yang mencoba mengupdate
    $stmt_check_owner = mysqli_prepare($conn, "SELECT user_id FROM posts WHERE id = ?");
    if (!$stmt_check_owner) {
        throw new Exception('Gagal menyiapkan statement cek pemilik: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_check_owner, "i", $post_id);
    mysqli_stmt_execute($stmt_check_owner);
    $result_owner = mysqli_stmt_get_result($stmt_check_owner);
    $post_owner = mysqli_fetch_assoc($result_owner);
    mysqli_stmt_close($stmt_check_owner);

    if (!$post_owner) {
        send_json_response(['success' => false, 'message' => 'Postingan tidak ditemukan.'], 404);
    }

    if ($post_owner['user_id'] != $user_id) {
        send_json_response(['success' => false, 'message' => 'Anda tidak memiliki izin untuk mengupdate postingan ini.'], 403);
    }

    // 2. Cek apakah category_id valid
    $stmt_category_check = mysqli_prepare($conn, "SELECT id FROM categories WHERE id = ?");
    if (!$stmt_category_check) throw new Exception('Gagal menyiapkan statement cek kategori: ' . mysqli_error($conn));
    mysqli_stmt_bind_param($stmt_category_check, "i", $category_id);
    mysqli_stmt_execute($stmt_category_check);
    mysqli_stmt_store_result($stmt_category_check);
    if (mysqli_stmt_num_rows($stmt_category_check) == 0) {
        mysqli_stmt_close($stmt_category_check);
        send_json_response(['success' => false, 'message' => 'Kategori tidak ditemukan.'], 404);
    }
    mysqli_stmt_close($stmt_category_check);

    // 3. Lakukan update postingan
    // DIUBAH: Tambahkan kolom `image` ke query UPDATE
    $stmt_update = mysqli_prepare($conn, "UPDATE posts SET category_id = ?, title = ?, slug = ?, content = ?, image = ?, updated_at = NOW() WHERE id = ?");
    if (!$stmt_update) {
        throw new Exception('Gagal menyiapkan statement update postingan: ' . mysqli_error($conn));
    }
    // Bind parameter: issssi -> integer (category_id), string (title), string (slug), string (content), string (image_url), integer (post_id)
    mysqli_stmt_bind_param(
        $stmt_update,
        "issssi",
        $category_id,
        $title,
        $slug,
        $content,
        $image_url, // Bind URL gambar di sini
        $post_id
    );
    mysqli_stmt_execute($stmt_update);
    mysqli_stmt_close($stmt_update);

    // 4. Ambil data postingan yang diperbarui setelah update
    $sql_fetch_updated_post = "
        SELECT
            p.id, p.user_id, u.username,
            p.category_id, c.name as category_name,
            p.title, p.slug, p.content, p.image, p.type, p.is_published, p.is_banned,
            p.created_at, p.updated_at,
            (SELECT COALESCE(SUM(CASE WHEN type = 'up' THEN 1 ELSE 0 END), 0) FROM votes WHERE post_id = p.id) AS upvote_count,
            (SELECT COALESCE(SUM(CASE WHEN type = 'down' THEN 1 ELSE 0 END), 0) FROM votes WHERE post_id = p.id) AS downvote_count,
            (SELECT COUNT(id) FROM comments WHERE post_id = p.id) AS comment_count,
            (SELECT CASE WHEN id IS NOT NULL THEN TRUE ELSE FALSE END FROM saved_posts WHERE post_id = p.id AND user_id = ? LIMIT 1) AS is_saved_by_user,
            (SELECT type FROM votes WHERE post_id = p.id AND user_id = ? LIMIT 1) AS user_vote_type
        FROM posts p
        JOIN users u ON p.user_id = u.id
        JOIN categories c ON p.category_id = c.id
        WHERE p.id = ?
        GROUP BY p.id, u.username, c.name, p.title, p.slug, p.content, p.image, p.type, p.is_published, p.is_banned, p.created_at, p.updated_at, is_saved_by_user, user_vote_type
        LIMIT 1
    ";

    $stmt_fetch_post = mysqli_prepare($conn, $sql_fetch_updated_post);
    if (!$stmt_fetch_post) {
        throw new Exception('Gagal menyiapkan statement fetch updated post: ' . mysqli_error($conn));
    }
    // Bind user_id dua kali untuk subquery is_saved_by_user dan user_vote_type, lalu post_id
    mysqli_stmt_bind_param($stmt_fetch_post, "iii", $user_id, $user_id, $post_id);
    mysqli_stmt_execute($stmt_fetch_post);
    $result_fetch_post = mysqli_stmt_get_result($stmt_fetch_post);
    $updated_post = mysqli_fetch_assoc($result_fetch_post);
    mysqli_stmt_close($stmt_fetch_post);

    if ($updated_post) {
        $updated_post['is_saved_by_user'] = (bool)$updated_post['is_saved_by_user'];

        // Ambil data komentar untuk postingan ini
        $sql_fetch_comments = "
            SELECT
                comm.id, comm.user_id, u_comm.username, comm.post_id, comm.parent_id, comm.content, comm.is_deleted, comm.created_at, comm.updated_at
            FROM comments comm
            JOIN users u_comm ON comm.user_id = u_comm.id
            WHERE comm.post_id = ?
            ORDER BY comm.created_at ASC
        ";
        $stmt_fetch_comments = mysqli_prepare($conn, $sql_fetch_comments);
        if (!$stmt_fetch_comments) {
            error_log('Gagal menyiapkan statement fetch comments: ' . mysqli_error($conn));
            $updated_post['comments'] = []; // Tetapkan array kosong jika gagal
        } else {
            mysqli_stmt_bind_param($stmt_fetch_comments, "i", $post_id);
            mysqli_stmt_execute($stmt_fetch_comments);
            $result_comments = mysqli_stmt_get_result($stmt_fetch_comments);
            $all_comments = [];
            while ($row = mysqli_fetch_assoc($result_comments)) {
                $row['is_deleted'] = (bool)$row['is_deleted'];
                $all_comments[] = $row;
            }
            mysqli_stmt_close($stmt_fetch_comments);

            $updated_post['comments'] = build_nested_comments($all_comments);
        }

        send_json_response(['success' => true, 'message' => 'Postingan berhasil diperbarui!', 'data' => $updated_post], 200);
    } else {
        send_json_response(['success' => false, 'message' => 'Postingan berhasil diperbarui, tetapi gagal mengambil detailnya.'], 500);
    }
} catch (Exception $e) {
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan saat memperbarui postingan: ' . $e->getMessage()], 500);
}