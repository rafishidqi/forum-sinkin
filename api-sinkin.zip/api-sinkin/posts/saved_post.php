<?php
// saved_post.php
require_once '../koneksi.php'; // Asumsi file koneksi database Anda
require_once '../utils/helpers.php'; // Asumsi file helpers.php Anda yang berisi send_json_response, set_cors_headers, dan build_nested_comments

// Set header CORS
set_cors_headers();

// Pastikan metode request adalah GET
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405);
}

// Ambil user_id dari parameter GET
$user_id = $_GET['user_id'] ?? null;

// Validasi input user_id
if (empty($user_id) || !is_numeric($user_id)) {
    send_json_response(['success' => false, 'message' => 'User ID wajib diisi dan harus berupa angka.'], 400);
}

try {
    // Query untuk mengambil semua postingan yang disimpan oleh user_id ini
    // dan juga detail lengkap dari setiap postingan tersebut.
    $sql_fetch_saved_posts = "
        SELECT
            p.id, p.user_id AS author_id, u.username AS author_username,
            p.category_id, c.name AS category_name,
            p.title, p.slug, p.content, p.image, p.type, p.is_published, p.is_banned,
            p.created_at, p.updated_at,
            (SELECT COALESCE(SUM(CASE WHEN type = 'up' THEN 1 ELSE 0 END), 0) FROM votes WHERE post_id = p.id) AS upvote_count,
            (SELECT COALESCE(SUM(CASE WHEN type = 'down' THEN 1 ELSE 0 END), 0) FROM votes WHERE post_id = p.id) AS downvote_count,
            (SELECT COUNT(id) FROM comments WHERE post_id = p.id) AS comment_count,
            (SELECT CASE WHEN id IS NOT NULL THEN TRUE ELSE FALSE END FROM saved_posts WHERE post_id = p.id AND user_id = ? LIMIT 1) AS is_saved_by_user,
            (SELECT type FROM votes WHERE post_id = p.id AND user_id = ? LIMIT 1) AS user_vote_type
        FROM
            saved_posts sp
        JOIN
            posts p ON sp.post_id = p.id
        JOIN
            users u ON p.user_id = u.id
        JOIN
            categories c ON p.category_id = c.id
        WHERE
            sp.user_id = ?
        ORDER BY
            sp.created_at DESC;
    ";

    $stmt_fetch_saved_posts = mysqli_prepare($conn, $sql_fetch_saved_posts);
    if (!$stmt_fetch_saved_posts) {
        throw new Exception('Gagal menyiapkan statement fetch saved posts: ' . mysqli_error($conn));
    }

    // Bind parameter untuk subquery is_saved_by_user, user_vote_type, dan filter utama sp.user_id
    // 'iii' menunjukkan tiga parameter integer
    mysqli_stmt_bind_param($stmt_fetch_saved_posts, "iii", $user_id, $user_id, $user_id);
    mysqli_stmt_execute($stmt_fetch_saved_posts);
    $result_fetch_saved_posts = mysqli_stmt_get_result($stmt_fetch_saved_posts);

    $saved_posts_data = [];
    while ($post = mysqli_fetch_assoc($result_fetch_saved_posts)) {
        // Konversi nilai boolean
        $post['is_saved_by_user'] = (bool)$post['is_saved_by_user'];
        $post['is_published'] = (int)$post['is_published'];
        $post['is_banned'] = (int)$post['is_banned'];

        // Ambil data komentar untuk postingan ini
        $sql_fetch_comments = "
            SELECT
                comm.id, comm.user_id, u_comm.username, comm.post_id, comm.parent_id, comm.content, comm.is_deleted, comm.created_at, comm.updated_at
            FROM comments comm
            JOIN users u_comm ON comm.user_id = u_comm.id
            WHERE comm.post_id = ?
            ORDER BY comm.created_at ASC
        ";
        $stmt_fetch_comments = mysqli_prepare($conn, $sql_fetch_comments);
        if (!$stmt_fetch_comments) {
            error_log('Gagal menyiapkan statement fetch comments untuk post ID ' . $post['id'] . ': ' . mysqli_error($conn));
            $post['comments'] = []; // Tetapkan array kosong jika gagal
        } else {
            mysqli_stmt_bind_param($stmt_fetch_comments, "i", $post['id']);
            mysqli_stmt_execute($stmt_fetch_comments);
            $result_comments = mysqli_stmt_get_result($stmt_fetch_comments);
            $all_comments = [];
            while ($row = mysqli_fetch_assoc($result_comments)) {
                $row['is_deleted'] = (bool)$row['is_deleted'];
                $all_comments[] = $row;
            }
            mysqli_stmt_close($stmt_fetch_comments);

            // Gunakan fungsi build_nested_comments dari helpers.php
            $post['comments'] = build_nested_comments($all_comments);
        }

        $saved_posts_data[] = $post;
    }
    mysqli_stmt_close($stmt_fetch_saved_posts);

    send_json_response(['success' => true, 'message' => 'Postingan yang disimpan berhasil diambil.', 'data' => $saved_posts_data], 200);
} catch (Exception $e) {
    // Tangani kesalahan umum
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()], 500);
}