<?php
// soft_delete.php
require_once '../koneksi.php'; // Sesuaikan path jika berbeda
require_once '../utils/helpers.php'; // Sesuaikan path jika berbeda

set_cors_headers();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405); // Method Not Allowed
}

$user_id = $_POST['user_id'] ?? null;
$post_id = $_POST['post_id'] ?? null;

// Validasi input
if (empty($user_id) || empty($post_id)) {
    send_json_response(['success' => false, 'message' => 'User ID dan Post ID wajib diisi.'], 400); // Bad Request
}

try {
    // Cek apakah postingan ada dan dimiliki oleh user yang mencoba menghapus
    $stmt_check = mysqli_prepare($conn, "SELECT id, user_id FROM posts WHERE id = ?");
    if (!$stmt_check) {
        throw new Exception('Gagal menyiapkan statement cek postingan: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_check, "i", $post_id);
    mysqli_stmt_execute($stmt_check);
    $result_check = mysqli_stmt_get_result($stmt_check);
    $post_data = mysqli_fetch_assoc($result_check);
    mysqli_stmt_close($stmt_check);

    if (!$post_data) {
        send_json_response(['success' => false, 'message' => 'Postingan tidak ditemukan.'], 404); // Not Found
    }

    if ($post_data['user_id'] != $user_id) {
        send_json_response(['success' => false, 'message' => 'Anda tidak memiliki izin untuk menghapus postingan ini.'], 403); // Forbidden
    }

    // Lakukan soft delete: set is_published menjadi 0
    $stmt_update = mysqli_prepare($conn, "UPDATE posts SET is_published = 0, updated_at = NOW() WHERE id = ?");
    if (!$stmt_update) {
        throw new Exception('Gagal menyiapkan statement update postingan: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_update, "i", $post_id);
    mysqli_stmt_execute($stmt_update);
    mysqli_stmt_close($stmt_update);

    // DIUBAH: Hapus pengambilan dan pengembalian objek $updated_post.
    // Sekarang hanya mengirim pesan sukses.
    send_json_response(['success' => true, 'message' => 'Postingan berhasil dihapus (soft delete).'], 200);
} catch (Exception $e) {
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan saat menghapus postingan: ' . $e->getMessage()], 500); // Internal Server Error
}