<?php

$server = "localhost";
$user = "root";
$pass = "";
$database = "forum_sinkin";
$conn = mysqli_connect($server, $user, $pass, $database);
if (mysqli_connect_errno()) {
    echo "Gagal Koneksi MySQL" . mysqli_connect_error();
}