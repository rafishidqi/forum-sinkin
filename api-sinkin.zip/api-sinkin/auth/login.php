<?php
// login.php
require_once '../koneksi.php'; // Memuat koneksi mysqli
require_once '../utils/helpers.php';   // Memuat fungsi pembantu (CORS, JSON response)

set_cors_headers(); // Atur header CORS untuk mengizinkan permintaan dari aplikasi Android

// Pastikan metode request adalah POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405); // Method Not Allowed
}

// Dapatkan input dari $_POST
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Validasi input dasar
if (empty($username) || empty($password)) {
    send_json_response(['success' => false, 'message' => 'Username dan password wajib diisi.'], 400); // Bad Request
}

// Cek khusus untuk "admin" dengan password "admin"
// Ini adalah logika yang Anda minta, namun di lingkungan produksi,
// akun admin sebaiknya tidak memiliki login di API publik dan harus di-hash password-nya.
if ($username === 'admin' && $password === 'admin') {
    send_json_response([
        "success" => false,
        "message" => "Login tidak diizinkan untuk akun ini."
    ], 403); // Forbidden
}

// Ambil data pengguna LENGKAP dari database berdasarkan username
// Menggunakan prepared statement untuk mencegah SQL Injection
$stmt = mysqli_prepare($conn, "SELECT id, name, username, email, password, avatar, bio, is_active FROM users WHERE username = ?");
if (!$stmt) {
    send_json_response(['success' => false, 'message' => 'Gagal menyiapkan statement: ' . mysqli_error($conn)], 500);
}

mysqli_stmt_bind_param($stmt, "s", $username); // "s" menunjukkan tipe data string untuk username
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result); // Mengambil satu baris data pengguna

// Verifikasi apakah pengguna ditemukan dan password cocok
// PENTING: password_verify() digunakan untuk memverifikasi password yang di-hash.
// Pastikan password di database Anda di-hash saat registrasi menggunakan password_hash().
// Jika password di database Anda masih plain text, verifikasi ini akan selalu gagal.
if ($user && password_verify($password, $user['password'])) {
    // --- Implementasi Token Sederhana (TIDAK AMAN UNTUK PRODUKSI!) ---
    // Di lingkungan produksi, Anda SANGAT DISARANKAN untuk menggunakan library JWT (JSON Web Token)
    // yang kuat (misalnya, firebase/php-jwt) untuk menghasilkan token yang aman,
    // dapat diverifikasi, dan memiliki masa berlaku.
    // Contoh ini hanya untuk ILUSTRASI dasar bagaimana token bisa dikembalikan.
    // Token ini hanya di-encode base64 dan tidak memiliki tanda tangan kriptografis,
    // sehingga mudah dipalsukan.

    // Data yang akan di-encode dalam token
    $token_payload = [
        'user_id' => $user['id'],
        'username' => $user['username'],
        'exp' => time() + (3600 * 24) // Token berlaku 24 jam dari sekarang (timestamp)
    ];

    // Encode payload menjadi token base64 sederhana
    $token = base64_encode(json_encode($token_payload));

    // --- Akhir Implementasi Token Sederhana ---

    // Hapus password hashed dari array pengguna sebelum mengirimkannya ke klien
    unset($user['password']);

    // Kirim respons sukses dengan data pengguna dan token
    send_json_response([
        'success' => true,
        'message' => 'Login berhasil!',
        'user' => [ // Mengembalikan semua data user yang relevan dari tabel users
            'id' => (int)$user['id'], // Pastikan ini dikonversi ke integer
            'name' => $user['name'],
            'username' => $user['username'],
            'email' => $user['email'],
            'avatar' => $user['avatar'],
            'bio' => $user['bio'],
            'is_active' => (bool)$user['is_active'], // Pastikan ini dikonversi ke boolean
        ],
        'token' => $token // Kirim token ke aplikasi Android
    ], 200); // OK
} else {
    // Login gagal (pengguna tidak ditemukan atau password salah)
    send_json_response([
        "success" => false,
        "message" => "Username atau password salah." // Tambahkan pesan lebih spesifik
    ], 401); // Unauthorized
}

// Tutup statement
mysqli_stmt_close($stmt);
// Koneksi $conn akan ditutup secara otomatis saat skrip selesai,
// atau Anda bisa menutupnya secara eksplisit jika diperlukan: mysqli_close($conn);