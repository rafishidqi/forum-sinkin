<?php
// register.php
// Asumsi: koneksi.php berada di direktori induk dari folder auth/
require_once '../koneksi.php'; // Memuat koneksi mysqli
require_once '../utils/helpers.php';   // Memuat fungsi pembantu (CORS, JSON response)

set_cors_headers(); // Atur header CORS untuk mengizinkan permintaan dari aplikasi Android

// Pastikan metode request adalah POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405); // Method Not Allowed
}

// Dapatkan input dari $_POST
$username = $_POST['username'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$password_confirmation = $_POST['password_confirmation'] ?? '';

// Validasi input
if (empty($username) || empty($email) || empty($password) || empty($password_confirmation)) {
    send_json_response(['success' => false, 'message' => 'Semua field wajib diisi.'], 400); // Bad Request
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    send_json_response(['success' => false, 'message' => 'Format email tidak valid.'], 400); // Bad Request
}
if (strlen($password) < 3) {
    send_json_response(['success' => false, 'message' => 'Password minimal 3 karakter.'], 400); // Bad Request
}
if ($password !== $password_confirmation) {
    send_json_response(['success' => false, 'message' => 'Konfirmasi password tidak cocok.'], 400); // Bad Request
}

// Cek apakah username atau email sudah terdaftar di database
$stmt_check = mysqli_prepare($conn, "SELECT id FROM users WHERE username = ? OR email = ?");
if (!$stmt_check) {
    send_json_response(['success' => false, 'message' => 'Gagal menyiapkan statement cek: ' . mysqli_error($conn)], 500);
}
mysqli_stmt_bind_param($stmt_check, "ss", $username, $email);
mysqli_stmt_execute($stmt_check);
mysqli_stmt_store_result($stmt_check); // Simpan hasil untuk mysqli_stmt_num_rows

if (mysqli_stmt_num_rows($stmt_check) > 0) {
    mysqli_stmt_close($stmt_check);
    send_json_response(['success' => false, 'message' => 'Username atau email sudah terdaftar.'], 409); // Conflict
}
mysqli_stmt_close($stmt_check);

// Hash password sebelum menyimpan ke database
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Siapkan nilai default untuk kolom yang tidak disediakan oleh registrasi
$name = $username; // Menggunakan username sebagai nama default
$avatar = null;    // Default null
$bio = null;       // Default null
$is_active = 1;    // Default aktif
$email_verified_at = null; // Default null
$remember_token = null;    // Default null

// Simpan pengguna baru ke database
// Menggunakan prepared statement untuk mencegah SQL Injection
$stmt_insert = mysqli_prepare($conn, "INSERT INTO users (name, username, email, password, avatar, bio, is_active, email_verified_at, remember_token, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");

if (!$stmt_insert) {
    send_json_response(['success' => false, 'message' => 'Gagal menyiapkan statement insert: ' . mysqli_error($conn)], 500);
}

mysqli_stmt_bind_param(
    $stmt_insert,
    "sssssbiss",
    $name,
    $username,
    $email,
    $hashed_password,
    $avatar,
    $bio,
    $is_active,
    $email_verified_at,
    $remember_token
);

if (mysqli_stmt_execute($stmt_insert)) {
    $user_id = mysqli_insert_id($conn); // Dapatkan ID pengguna yang baru dibuat
    // Di lingkungan produksi, Anda mungkin ingin membuat dan mengembalikan token autentikasi di sini
    // untuk langsung login pengguna setelah registrasi.
    send_json_response([
        'success' => true,
        'message' => 'Registrasi berhasil!',
        'user_id' => $user_id // Mengembalikan ID pengguna yang baru dibuat
    ], 201); // Created
} else {
    send_json_response(['success' => false, 'message' => 'Gagal mendaftar pengguna: ' . mysqli_error($conn)], 500); // Internal Server Error
}

mysqli_stmt_close($stmt_insert);
// Koneksi $conn akan ditutup secara otomatis saat skrip selesai.