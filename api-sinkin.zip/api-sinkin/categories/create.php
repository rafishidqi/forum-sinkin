<?php
// create.php (untuk membuat kategori baru)
// SANGAT PENTING: PASTIKAN TIDAK ADA SPASI, BARIS KOSONG, ATAU KARAKTER LAIN SEBELUM TAG <?php INI
// ATAU SETELAH TAG PENUTUP (disarankan untuk TIDAK menggunakan tag penutup di file PHP murni)

require_once '../koneksi.php'; // Sesuaikan path jika berbeda
require_once '../utils/helpers.php'; // Sesuaikan path jika berbeda

set_cors_headers();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405); // Method Not Allowed
}

// Dapatkan input dari $_POST (karena di Android menggunakan @FormUrlEncoded)
$name = $_POST['name'] ?? '';
$description = $_POST['description'] ?? null; // Deskripsi bisa null

// Validasi input
if (empty($name)) {
    send_json_response(['success' => false, 'message' => 'Nama kategori wajib diisi.'], 400); // Bad Request
}

$name = trim($name);
$description = trim($description); // Trim deskripsi juga

if (empty($name)) {
    send_json_response(['success' => false, 'message' => 'Nama kategori tidak boleh kosong setelah trim.'], 400);
}

// Buat slug dari nama kategori
$slug = generate_slug($name); // Asumsi fungsi generate_slug ada di helpers.php

try {
    // Cek apakah kategori dengan nama atau slug yang sama sudah ada
    $stmt_check = mysqli_prepare($conn, "SELECT id FROM categories WHERE name = ? OR slug = ?");
    if (!$stmt_check) {
        throw new Exception('Gagal menyiapkan statement cek kategori: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_check, "ss", $name, $slug);
    mysqli_stmt_execute($stmt_check);
    mysqli_stmt_store_result($stmt_check);
    if (mysqli_stmt_num_rows($stmt_check) > 0) {
        mysqli_stmt_close($stmt_check);
        send_json_response(['success' => false, 'message' => 'Kategori dengan nama atau slug ini sudah ada.'], 409); // Conflict
    }
    mysqli_stmt_close($stmt_check);

    // Masukkan kategori baru ke database
    $sql_insert_category = "INSERT INTO categories (name, slug, description, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())";
    $stmt_insert = mysqli_prepare($conn, $sql_insert_category);
    if (!$stmt_insert) {
        throw new Exception('Gagal menyiapkan statement insert kategori: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_insert, "sss", $name, $slug, $description);

    if (mysqli_stmt_execute($stmt_insert)) {
        $new_category_id = mysqli_insert_id($conn); // Dapatkan ID kategori yang baru dibuat

        // Ambil data kategori yang baru dibuat untuk dikembalikan ke aplikasi
        $sql_fetch_new_category = "
            SELECT id, name, slug, description, created_at, updated_at
            FROM categories
            WHERE id = ?
            LIMIT 1
        ";
        $stmt_fetch_new_category = mysqli_prepare($conn, $sql_fetch_new_category);
        if (!$stmt_fetch_new_category) {
            error_log('Gagal menyiapkan statement fetch kategori baru: ' . mysqli_error($conn));
            mysqli_stmt_close($stmt_insert);
            throw new Exception('Gagal menyiapkan statement fetch kategori.');
        }
        mysqli_stmt_bind_param($stmt_fetch_new_category, "i", $new_category_id);
        mysqli_stmt_execute($stmt_fetch_new_category);
        $result_new_category = mysqli_stmt_get_result($stmt_fetch_new_category);
        $new_category_data = mysqli_fetch_assoc($result_new_category);
        mysqli_stmt_close($stmt_fetch_new_category);
        mysqli_stmt_close($stmt_insert);

        if ($new_category_data) {
            // Tambahkan is_followed_by_user = false secara default untuk kategori baru
            $new_category_data['is_followed_by_user'] = false;
            send_json_response([
                'success' => true,
                'message' => 'Kategori berhasil dibuat!',
                'data' => $new_category_data // Mengembalikan objek kategori yang baru dibuat
            ], 201); // Created
        } else {
            send_json_response(['success' => false, 'message' => 'Kategori dibuat, tetapi gagal mengambil detailnya.'], 500);
        }
    } else {
        send_json_response(['success' => false, 'message' => 'Gagal membuat kategori: ' . mysqli_error($conn)], 500);
    }
} catch (Exception $e) {
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan saat membuat kategori: ' . $e->getMessage()], 500); // Internal Server Error
}