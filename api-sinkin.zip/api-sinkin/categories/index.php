<?php
// index.php (untuk mendapatkan daftar kategori)
require_once '../koneksi.php'; // Sesuaikan path jika berbeda
require_once '../utils/helpers.php'; // Sesuaikan path jika berbeda

set_cors_headers();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405); // Method Not Allowed
}

$user_id = $_GET['user_id'] ?? null; // DIUBAH: Dapatkan user_id opsional

$categories = [];
try {
    // DIUBAH: Tambahkan subkueri untuk menentukan is_followed_by_user
    $sql = "
        SELECT 
            c.id, c.name, c.slug, c.created_at, c.updated_at,
            (SELECT CASE WHEN COUNT(ucf.id) > 0 THEN TRUE ELSE FALSE END 
             FROM user_category_followers ucf 
             WHERE ucf.category_id = c.id AND ucf.user_id = ?) AS is_followed_by_user
        FROM categories c
        ORDER BY c.name ASC
    ";

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        throw new Exception('Gagal menyiapkan statement kategori: ' . mysqli_error($conn));
    }

    // Bind user_id. Jika $user_id null, bind 0 atau ID non-existent agar subquery selalu false
    $bind_user_id = $user_id !== null ? (int)$user_id : 0;
    mysqli_stmt_bind_param($stmt, "i", $bind_user_id);

    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            // Konversi is_followed_by_user ke boolean
            $row['is_followed_by_user'] = (bool)$row['is_followed_by_user'];
            $categories[] = $row;
        }
        mysqli_free_result($result);
        send_json_response(['success' => true, 'data' => $categories], 200);
    } else {
        throw new Exception('Gagal mengambil kategori: ' . mysqli_error($conn));
    }
} catch (Exception $e) {
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()], 500); // Internal Server Error
}