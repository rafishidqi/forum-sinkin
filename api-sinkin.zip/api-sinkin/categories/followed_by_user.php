<?php
// followed_by_user.php
require_once '../koneksi.php'; // Sesuaikan path jika berbeda
require_once '../utils/helpers.php'; // Sesuaikan path jika berbeda

set_cors_headers();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    send_json_response(['success' => false, 'message' => 'Metode request tidak diizinkan.'], 405);
}

$user_id = $_GET['user_id'] ?? null;

// Validasi input
if (empty($user_id)) {
    send_json_response(['success' => false, 'message' => 'User ID wajib diisi.'], 400);
}

try {
    // Ambil daftar category_id yang diikuti oleh pengguna
    $followed_category_ids = [];
    $stmt_followed_categories = mysqli_prepare($conn, "SELECT category_id FROM user_category_followers WHERE user_id = ?");
    if (!$stmt_followed_categories) {
        throw new Exception('Gagal menyiapkan statement kategori yang diikuti: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_followed_categories, "i", $user_id);
    mysqli_stmt_execute($stmt_followed_categories);
    $result_followed_categories = mysqli_stmt_get_result($stmt_followed_categories);

    while ($row = mysqli_fetch_assoc($result_followed_categories)) {
        $followed_category_ids[] = $row['category_id'];
    }
    mysqli_stmt_close($stmt_followed_categories);

    $categories = [];
    if (!empty($followed_category_ids)) {
        // Buat placeholder untuk query IN clause
        $placeholders = implode(',', array_fill(0, count($followed_category_ids), '?'));
        $types = str_repeat('i', count($followed_category_ids));

        // Ambil detail kategori berdasarkan ID yang diikuti
        $sql_categories = "SELECT id, name FROM categories WHERE id IN ($placeholders) ORDER BY name ASC";
        $stmt_categories_detail = mysqli_prepare($conn, $sql_categories);
        if (!$stmt_categories_detail) {
            throw new Exception('Gagal menyiapkan statement detail kategori: ' . mysqli_error($conn));
        }

        // Bind parameter secara dinamis
        $refs = [];
        foreach ($followed_category_ids as $key => $value) {
            $refs[$key] = &$followed_category_ids[$key];
        }
        call_user_func_array('mysqli_stmt_bind_param', array_merge([$stmt_categories_detail, $types], $refs));

        mysqli_stmt_execute($stmt_categories_detail);
        $result_categories_detail = mysqli_stmt_get_result($stmt_categories_detail);

        while ($row = mysqli_fetch_assoc($result_categories_detail)) {
            $categories[] = $row;
        }
        mysqli_stmt_close($stmt_categories_detail);
    }

    send_json_response(['success' => true, 'message' => 'Kategori yang diikuti berhasil dimuat.', 'data' => $categories], 200);
} catch (Exception $e) {
    send_json_response(['success' => false, 'message' => 'Terjadi kesalahan: ' . $e->getMessage()], 500);
}